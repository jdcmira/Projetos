#****************************************************************************
#                                                                           *
#               JORGE MIRA, NUM. 87543, LETI                                *
#                                                                           *
#****************************************************************************

# 2: TAD
# 2.1

# Construtores

def int_naoneg (n):
    ''' Funcao adicional que verifica se o argumento corresponde a um inteiro positivo ou zero, devolvendo os valores logicos True (caso
    positivo) ou False (se nao se verifica). Isinstance retorna igualmente True se o objeto (argumento de indice 0) e da classe do
    argumento 1, o mesmo poderia ter sido obtido com, p. ex., type(i) is int.'''
    return isinstance (n, int) and n >= 0

def faz_pos (l, c):
    ''' A funcao verifica a validade dos argumentos e devolve a posicao (linha e coluna)
    se forem validos. Caso nao o sejam, retorna erro. '''
    if int_naoneg(l) and int_naoneg(c):
        return (l, c)
    else:
        raise ValueError ('faz_pos: argumentos errados')

# Seletores
def linha_pos (p):
    ''' Para um tuple (definido arbitrariamente) da forma (linha, coluna), o indice corresponde a linha e zero. '''
    return p[0]

def coluna_pos (p):
    ''' O mesmo se verifica, onde a funcao devolve o elemento no indice 1 a que lhe corresponde a coluna. '''
    return p[1]

# Reconhecedor
def e_pos (p):
    ''' A operacao basica definida como reconhecedor verifica se todas as condicoes se satisfazem, isto e, identificam elementos do tipo,
    onde posicao e um tuple com 2 valores numericos, onde ambos sao inteiros nao negativos.'''
    return isinstance(p, tuple) and len(p) == 2 and int_naoneg (p[0]) and int_naoneg (p[1])

# Testes
def pos_iguais (p1, p2):
    ''' A funcao devolve True sse tanto a linha como a coluna sao iguais.'''
    return p1 == p2 #O mesmo que ter p1[0] == p2[0] and p1[1] == p2[1], ambos com len == 2

# 2.2

#Construtores
def valida_arg1 (l, mgc):
    ''' Antes das funcoes gera_chave (linhas e espiral) foi definido funcoes adicionais que verificam primeiro a validade dos argumentos
    dados, devolvendo erro alguma condicao (definida para l, mgc, s e pos) nao se verificar. As funcoes prosseguem se estiver de acordo.
    Esta funcao adicional devolve a validade para os argumentos l e mgc onde correspondem respetivamente a um tuple de 25 letras, nenhuma
    repetida, e uma string cujos caracteres sao letras, contidas em l, ou espaços'''
    v = ''
    if isinstance(l, tuple) and isinstance(mgc, str) and len(l) == 25:
        for i in l:
            if i not in v:
                v += i
            else:                # O ciclo for vai juntando sucessivamente todas as letras de l numa lista inicialmente vazia. Se uma das
                return False     # letras ja la estiver, entao a letra esta repetida em l, retornando logo o valor False
        for j in mgc:                       # Se algum dos caracteres nao estiver em v (nao pertencer a l, funciona igualmente j not in l)
            if j not in v and j != ' ':     # nem for um espaço, entao o caracter nao e valido.
                return False
        return True
    else:
        return False

def valida_arg2 (s, pos):
    ''' A funcao verifica se s corresponde a uma das duas strings validas (para o sentido relogio ou contrario) e se pos e um dos 4
    cantos possiveis. As condicoes dadas para pos ja verificam consequentemente se e um tuple e de tamanho 2. '''
    return (s == 'r' or s == 'c') and (pos == (0,0) or pos == (0,4) or pos == (4,0) or pos == (4,4))

def chave_inicial (l, mgc):
    ''' A chave inicial e uma versao preliminar para as gera_chave_linhas e gera_chaves_espiral. Corresponde a uma lista
    (definido arbitrariamente) de 25 caracteres pela ordem de mgc seguidos dos restantes elementos de l ordenados (e sem repeticoes). '''
    chave_i = []
    for c in mgc:                    # Ordena inicialmente pelos caracteres de mgc que nao sejam espacos
        if c not in chave_i and c != ' ':
            chave_i += [c]
    for letra in l:                  # Para as letras restantes percorre sucessivamente os elementos de l
        if letra not in chave_i:
            chave_i += [letra]
    return chave_i

def gera_chave_linhas (l, mgc):
    '''A funcao devolve a lista que representa a matriz, isto e, uma lista de listas onde cada uma e uma linha da tabela, e os indices
    dessa lista (contida na lista principal) e a coluna a que pertencem. Caso os argumentos sejam validos (devolvido pela funcao auxiliar),
    o output correspondera a chave pedida'''
    if not valida_arg1(l, mgc):
        raise ValueError('gera_chave_linhas: argumentos errados')

    chave1 = chave_inicial(l, mgc)
    chave2 = []
    for i in range(0, 24, 5):
        chave2 += [chave1[i:i+5]] #A cada 5 elementos cria uma nova lista dentro de chave, ou seja, a linha seguinte da matriz
    return chave2

def pos_lim (s, pos):
    ''' Esta funcao auxiliar define os limites da matriz espiral onde diminui um valor da primeira linha ou coluna se esta e
    respetivamente inferior ou lado esquerdo, e aumenta um valor nos dois casos opostos. '''
    lim_esq, lim_dir, lim_sup, lim_inf = 0, 4, 0, 4  # limites
    dx, dy = 0, 0                                    # sentido

    if pos[0] == 0 and pos[1] == 0:
        if s == 'r':
            lim_sup += 1
            dx += 1
        else:
            lim_esq += 1
            dy += 1

    elif pos[0] == 0 and pos[1] == 4:
        if s == 'r':
            lim_dir += -1
            dy += 1
        else:
            lim_sup += 1
            dx += -1

    elif pos[0] == 4 and pos[1] == 0:
        if s == 'r':
            lim_esq += 1
            dy += -1
        else:
            lim_inf += -1
            dx += 1

    else: # Quando pos[0] == 4 and pos[1] == 4
        if s == 'r':
            lim_inf += -1
            dx += -1
        else:
            lim_dir += -1
            dy += -1

    return lim_esq, lim_dir, lim_sup, lim_inf, dx, dy

def muda_direcao(dx, dy, s):
    ''' Esta funcao adicional troca os valores de dx e de dy, onde dx e 1 aumentando o indice da linha
    e -1 se diminui. Do mesmo modo, temos que dy tem valor 1 quando percorre a coluna do indice 0 ao 4, e
    -1 se sobe na matriz (o seu indice diminui).'''
    if s == 'r':
        if dy == 0:
            return dy, dx
        if dx == 0:
            return -dy, dx
    else:
        if dy == 0:
            return dy, -dx
        if dx == 0:
            return dy, dx

def gera_chave_espiral(l, mgc, s, pos):
    ''' A funcao verifica com outra funcao adicional a validade dos argumentos correspondentes a "s" e a "pos", para alem
    daquela a que ja e devolvida por "valida_arg1", quando definido o valor de "k". Depois de verificado, calcula, recorrendo
    a funcao "pos_lim", os limites e posicao a que deve comecar, percorrendo cada caractere da chave inicial, e substituindo
    na chave nula. No final retorna a lista final obtida '''
    if not valida_arg1(l, mgc):
        raise ValueError('gera_chave_espiral: argumentos errados')
    if not valida_arg2 (s, pos):
        raise ValueError('gera_chave_espiral: argumentos errados')

    k = chave_inicial(l, mgc)                        # Chave com os elementos a ordenar
    l, c = pos[0], pos[1]                            # Coordenadas
    lim_esq, lim_dir, lim_sup, lim_inf, dx, dy = pos_lim(s, pos)
    m = [[0] * 5 for i in range(5)]                  # Matriz nula 5x5

    for e in range(25):
        m[l][c] = k[e]

        if dx > 0 and c >= lim_dir:                  # Suponhemos, para este caso, quando o ciclo percorre para o lado direito
            dx, dy = muda_direcao(dx, dy, s)         # (dx == 1) tendo ja chegado a um dos lados (c >= lim_dir). Entao, altera
            lim_dir -= 1                             # o eixo a que passa a percorrer diminuindo um valor do lado ja percorrido

        elif dx < 0 and c <= lim_esq:
            dx, dy = muda_direcao(dx, dy, s)
            lim_esq += 1

        elif dy > 0 and l >= lim_inf:
            dx, dy = muda_direcao(dx, dy, s)
            lim_inf -= 1

        elif dy < 0 and l <= lim_sup:
            dx, dy = muda_direcao(dx, dy, s)
            lim_sup += 1
        l += dy
        c += dx
    return m

# Seletor
def ref_chave (c, p):
    ''' A funcao retorna de chave o caractere cuja linha corresponde ao numero do primeiro elemento do tuple "p"
    e cuja coluna e o segundo elemento (caractere no indice 1) de "p" '''
    return c [p[0]] [p[1]]

# Modificador
def muda_chave (c, p, l):
    ''' Sendo a lista, definida pelas funcoes "gera_chave", um tipo mutavel, e posivel especificar que, para a linha
    p[0] da coluna p[1], o caracter dessa posicao tenha o valor de l. '''
    c [p[0]] [p[1]] = l
    return c

# Reconhecedores

def e_chave (c):
    ''' A funcao verifica se e chave, cujas condicoes sao, por ordem da funcao, ser uma lista de 5 elementos, cada um e tambem
    uma lista de tamanho 5, onde os seus elementos sao letras maiusculas (em ASCII compreendidas entre 65 (A) e 90 (Z)), onde
    nenhuma aparece repetida. O ciclo for, a semelhanca dos anteriores, verifica que nenhuma letra tinha antes parecido. '''
    if not (isinstance(c, list) and len(c) == 5):
        return False
    a = ''
    for ln in range(len(c)):
        if len(c[ln]) != 5:
            return False
        for cl in range(len(c[ln])):
            if c[ln][cl] not in a and ord(c[ln][cl]) in range(65, 91):
                a += c[ln][cl]
            else:
                return False
    return True

# Transformador
def string_chave (c):
    ''' A funcao vai incremento numa string inicialmente vazia as letras de chave, percorrendo cada uma sucessivamente pelo ciclo for.'''
    s = ''
    for ln in range(5):      # Percorre desde a linha 0 ate a quarta (5 nao fica incluido).
        if ln != 0:          # Sempre que passar para a linha seguinte (tuple seguinte de chave) faz paragrafo exceto primeiro
            s += '\n'        #   conforme " != 0 ".
        for cl in c[ln]:      # Apos cada letra deixa um espaço.
            s += cl + ' '
    s += '\n'                # No final de ter obtido a string "s" acrescenta mais um paragrafo
    return s


# 4: Funcoes a desenvolver:

def digramas (mens):
    ''' A funcao encripta a mensagem "mens", onde devolve a mesma sem espacos e com "X" entre letras repetidas. Para tal recorre a uma nova
    string "digrm" inicialmente vazia em que se acrescenta por ordem as letras de mens e, portanto, nao incluindo os espacos. Ademais, verifica
    se cada letra e igual a que se segue. Se sim, depois de adicionar esta acrescenta um "X" e continua a percorrer as letras.Se no final o
    numero de elementos for impar entao acrescenta mais um "X". '''
    digrm = ''
    for i in range(len(mens) - 1):    # Como dentro do ciclo for obtemos o elemento na posicao i+1, nao poderia chegar ate a ultima letra (i). Neste
       if mens[i] != ' ':             #   caso, verifica ate ao penultimo caractere.
           if mens[i] == mens[i+1]:
               digrm += mens[i] + 'X'
           else:                      # Corresponde a elif mens[i] != mens[i+1], nao precisa pois de verificar. Assim, adiciona o caractere de posicao
               digrm += mens[i]       #   i sem alteracao.
    if mens[len(mens) - 1] != ' ':    # Conforme mencionado, o ciclo for nao foi ate ao ultimo elemento, onde este e adicionado
        digrm += mens[len(mens) - 1]  #   caso nao seja um espaco.
    if len(digrm) % 2 == 1:           # Se o tamanho da string "digrm" for impar acrescenta 'X'. Caso seja par, nada acrescenta
        digrm += 'X'                  #   (nao precisa de clausula else)
    return digrm

def pos_letra (chave, letra):
    ''' A funcao verifica para o argumento "letra" todas as linhas e colunas possiveis sucessivamente ate que alguma
    contenha o caractere correspondente. Quando encontrar a lista da lista "chave" que contenha o elemento, devolve
    o numero da sua linha seguido do numero da coluna.'''
    for ln in range(5):
        for cl in range(5):              # A matriz e 5x5 (5 listas de tamanho 5 contidas noutra lista, a "chave")
            if chave [ln][cl] == letra:
                return (ln, cl)


def figura (digrm, chave):
    ''' A funcao recorre a uma funcao auxiliar, mais a frente tambem utilizada. "c1" e "c2" correspondem, respetivamente, a
    posicao do primeiro e do segundo caractere. Apos obter a posicao de ambos, verifica, na primeira condicao if, se tem a linha px[0]
    em comum (logo, que ambas formam uma linha na matriz), na segunda condicao if, se px[1] sao iguais (formando uma coluna),
    ou, caso nao tenham a linha nem a coluna em comum (indices distintos), formam um retangulo. '''
    p1 = pos_letra(chave, digrm[0])     # Corresponde a posicao de indice 0 de "digrm", a primeira letra
    p2 = pos_letra(chave, digrm[1])     # Corresponde a posicao de indice 1 de "digrm", a segunda letra
    if p1[0] == p2[0]:
        return ('l', p1, p2)
    elif p1[1] == p2[1]:
        return ('c', p1, p2)
    else:
        return ('r', p1, p2)

def encriptacao (pos, inc):
    ''' A funcao devolve o indice seguinte ou anterior conforme "inc" seja correspondentemente 1 (codifica) ou -1 (descodifica), quer
    se refira a linha ou a coluna (especificado no indice da respetiva funcao). O valor a somar coincide com o valor inc (quer este
    seja positivo ou negativo). Se o fim da linha ou coluna for atingido (quando ao indice 4 se soma 1) volta ao inicio desta
    (indice 0). Do mesmo modo, se o elemento estiver no indice 0 (for o primeiro da linha ou coluna), devolve o ultimo da mesma
    linha ou coluna (indice 4). '''
    if pos + inc == -1:
        return 4
    elif pos + inc == 5:
        return 0
    else:
        return pos + inc

def codifica_l (pos1, pos2, inc):
    ''' Para o codifica_l, correspondente a caracteres da mesma linha, o indice 0 nao altera enquanto que o indice 1 e o devolvido
    pela funcao auxiliar "encriptacao", isto e, devolve a mesma posicao com a coluna seguinte se inc == 1 ou a anterior se inc == -1.
    Se for uma coluna num dos extremos de um lado, o indice da coluna e o do extremo oposto. '''
    pos1_cod = (pos1[0], encriptacao (pos1[1], inc))
    pos2_cod = (pos2[0], encriptacao (pos2[1], inc))
    return (pos1_cod, pos2_cod)

def codifica_c (pos1, pos2, inc):
    ''' A semelhanca da funcao anterior, os elementos da mesma linha avancam ou retrocedem (de acordo com "inc") uma posicao, a menos
    que retrocedo para o indice o, que passa a 4 ou avance do indice 0, que e, conforme mencionado, indice 0. A posicao na coluna
    permanece inalterado. '''
    pos1_cod = (encriptacao (pos1[0], inc), pos1[1])
    pos2_cod = (encriptacao (pos2[0], inc), pos2[1])
    return (pos1_cod, pos2_cod)

def codifica_r(pos1, pos2):
    ''' Para os elementos de linhas e colunas diferentes, ambos os caracteres mantem a mesma linha e trocam entre si os indices
    da coluna. Desta forma, so o indice 1 da posicao e alterado, obtendo o valor da coluna que se encontra a outra letra (obtendo assim
    um retangulo). '''
    pos1_cod = (pos1[0], pos2[1])
    pos2_cod = (pos2[0], pos1[1])
    return (pos1_cod, pos2_cod)

def codifica_digrama (digrm, chave, inc):
    ''' A funcao recebe, para alem da "chave" e de "inc" (que indica se codifica ou descodifica), uma string de 2 caracteres.
    As condicoes if verificam a posicao das duas letras, dentre 3 possiveis, por esta ordem e recorrendo a funcao pos_letra,
    se tem a mesma linha (indice 0), se tem a mesma coluna (indice 1) ou nenhum dos dois (formando um retangulo). Para a posicao
    devolvida e depois destas encriptada (codificada ou descodificada) consoante os valores retornados por uma das funcoes
    anteriores "codifica" (linha, coluna ou retangulo). Apos obter os indices das posicoes devolve o caractere que na chave lhe
    corresponde. Desta forma, a funcao recebe os dois caracteres da matriz (lista) "chave" e troca um dos seus indices, de acordo
    com a posicao entre elas (isto recorrendo as funcoes "codifica" que processam as suas posicoes), e devolve uma string com
    os dois caracteres alterados. '''
    if pos_letra(chave, digrm[0])[0] == pos_letra(chave, digrm[1])[0]:              # Assim, neste caso, para a mesma linha,
        c = codifica_l(pos_letra(chave, digrm[0]), pos_letra(chave, digrm[1]), inc) # codifica-as
        return chave[c[0][0]][c[0][1]] + chave[c[1][0]][c[1][1]]                    # e devolve a letra que se encontra nessa posicao devolvida
    elif pos_letra(chave, digrm[0])[1] == pos_letra(chave, digrm[1])[1]:
        c = codifica_c(pos_letra(chave, digrm[0]), pos_letra(chave, digrm[1]), inc)
        return chave[c[0][0]][c[0][1]] + chave[c[1][0]][c[1][1]]
    else:
        c = codifica_r(pos_letra(chave, digrm[0]), pos_letra(chave, digrm[1]))
        return chave[c[0][0]][c[0][1]] + chave[c[1][0]][c[1][1]]

def codifica (mens, chave, inc):
    ''' A funcao cria uma nova string a qual e depois incrementada com valores devolvidos pela funcao anterior.
    O ciclo for salta de dois em dois pois pretende chamar a funcao anterior cujo primeiro argumento e de
    dois elementos. Pelo mesmo motivo, vai de um dado elemento, na posicao i, ate ao seguinte. Caso seja pretendido
    codificar, inicialmente a funcao tera de obter a string "mens" ja como digrama (obtida pela funcao "digramas")
    para que depois possa codificar. Se inc == -1 nao tera determinar o seu digrama pois esta e ja uma mensagem
    codificada. '''
    chave_cod = ''
    if inc == 1:
        for c in range(0, len(digramas(mens)), 2):
            digr = digramas(mens)
            chave_cod += codifica_digrama(digr[c : c+2], chave, inc)
    else:  # Se inc == -1
        for c in range(0, len(mens), 2):
            chave_cod += codifica_digrama(mens[c : c+2], chave, inc)
    return chave_cod