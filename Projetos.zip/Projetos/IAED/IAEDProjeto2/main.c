 
 /* * * * * * * * * * * * * * * * * * * * * * * *
  *	IAED										                    *
  *												                      *
  *	Jorge Mira- 87543		                        *
  *												                      *
  *	PROJETO 2									                  *
  *												                      *
  * * * * * * * * * * * * * * * * * * * * * * * */

#include "main.h"

int main()
/*	"command" é a letra a que lhe faz corresponder a respetiva função. A variável "check" é inicializada a
	1, para que, desta forma, a primeira chave a ser acrescentada seja definidia como a que tem maior
	stock atualmente, e, daí adiante, seja verificada a chave com maior quantia. "init" inicializa a variável
	head com valor nulo. O ciclo while, infinito, permite retornar a qualquer comando desejado. */
{
	char command;
	check = 1;
	init(&head);
	while (1)
	{
		command = getchar();	// Obtém letra
		switch (command)
		{
			case 'a':
				a_addproduct();	// Chama a função a_addproduct do ficheiro "command.c"
				break;			// break evita gastar recursos a verificar os restantes casos (não é poss. haver outro caso)
			case 'l':
				l_sort();
				break;
			case 'm':
				m_stock();
				break;
			case 'r':
				r_remproduct();
				break;
			case 'x':
				x_closeapp ();
				return EXIT_SUCCESS;	// Termina o programa com sucesso
			default:
				printf("%c\n", command);
				puts ("Error: Invalid command.");
		}
		getchar();						// Ignora o '\n' (Enter/New line)
	}
	return EXIT_FAILURE;	// O programa não foi executado corretamente
}