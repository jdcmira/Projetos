
#include "main.h"

#ifndef ITEM
#define ITEM

/* Abreviatura para o Tipo de dados da chave */

#define ULI unsigned long int


/* Estrutura do objeto: a chave em hexadecimal, e a quantidade da mesma no armazém. */

typedef struct objeto {
	ULI ch;					// Chave
	int qtd;				// Valor
} *Item;


/* Estutura que a cada item lhe corresponde o pointer para o seguinte item à esquerda e à direita na
árvore binária. */

typedef struct node {
	Item item;
	int height;
	struct node *l, *r;
} *link;


/* Funções-protótipo */

Item new_obj();
void print_obj();
int less();
int eq();
void init();

link new_item();
void modify_item();
link search();
void stock();
link insert();
link max();
void sort();
link search();
link delete();
void free_tree();

link rotL ();
link rotR ();
void update_height();
int height ();
link rotLR ();
link rotRL ();
int Balance();
link AVLbalance();

#endif