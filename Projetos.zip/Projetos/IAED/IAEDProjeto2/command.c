
#include "command.h"
#include "item.h"

/*	Comando 'a' onde acrescenta um novo objeto ao armazém ou atualiza a quantidade deste (aumenta se value > 0 e retira
	se value < 0). O objeto é igualado a 0 se for indicado para retirar mais unidades do que as que já existem. */

void a_addproduct ()
{
	long int code;							// Variável correspondente à chave
	int value;								// Variável para a quantidade do objeto
	scanf("%lx", &code);					// Ignora o espaço (entre 'a' e a chave) e obtém o valor da chave
	scanf("%d", &value);					// Obtém o valor
	Item produto = new_obj (code, value);	// Cria uma nova variável do tipo estrutura (de Item) com a mesma chave e valor
	if (num_obj_dif == 0)					// Se este for o primeiro objeto do armazém
		obj_mais_freq = produto;			// é definido como o de maior quantidade
	head = insert(head, produto);			// Insere o objeto na árvore e eventualmente atualiza a àrvore AVL
}


/*	Comando 'l' mostra as chaves organizadas por ordem alfabética (ordem numérica em hexadecimal). Por cada objeto adicionado,
	a árvore é organizada por ordem alfabética. Deste modo,será apenas necessário fazer print da raiz depois do filho esquerdo
	e antes do direito. */

void l_sort()
{
	sort(head);		// Chama a função "sort" com a raíz da árvore
}


/*	Comando 'm' escreve o produto com maior nº de unidades em stock, ou, em caso de igualdade,
	lista o produto com maior stock e a menor chave lexicográfica. */

void m_stock()
{
	if (num_obj_dif > 0)	// Caso não haja objetos no armazém não devolve nenhum output
	{
		if (!check)			// Se check == 0 verifica em toda a árvore qual o objeto com maior stock
		{
			obj_mais_freq = head->item;	// Define-se um produto aleatório como o maior (necessariamente existe head->item porque o armazém não está vazio)
			stock(head);				// Compara o obj_mais_freq com as restantes chaves (atualiza se um deles for maior)
			check = 1;					// Não precisa, até ao momento, de percorrer a árvore a verificar se nada nesta for alterado
		}
		print_obj(obj_mais_freq);		// Retorna o valor de "obj_mais_freq"
	}
}


/*	Comando 'r' que remove o objeto introduzido no input */

void r_remproduct()
{
	long int code;
	int value = 0;			// Define um valor qualquer para a quantidade (independentemente de qual seja, necessário apenas para obter a variável produto a remover)
	scanf("%lx", &code);	// Obtém a chave do produto a eliminar
	Item produto = new_obj (code, value);	// Cria a variável "produto" a utilizar na função "delete"
	if (!num_obj_dif)		// Se num_obj_dif == 0,
		return;				// então não faz nada (não vai retirar nenhum elemento a uma árvore vazia)
	if (eq(produto, obj_mais_freq))	// Se o produto a eliminar for já o objeto com maior stock no armazém,
		check = 0;					// então terá depois de verificar qual passa a ser o de maior quantidade
	if (search(head, produto))		// Decrementa uma unidade ao número de objetos difentes apenas se este já existe na árvore
		num_obj_dif--;				// (não contabiliza se for pedido para eliminar um produto que não existe no armazém)
	head = delete(head, produto);	// Recorrendo à função delete, "head" pode (ou não) ter um novo valor (caso o elemento a retirar seja a raíz da árvore)
}

/* Para terminar o programa, depois de retornar o número de objetos diferentes, faz free de todos os pointers */

void x_closeapp ()
{
	printf("%d\n", num_obj_dif); // Antes de terminar com sucesso o programa, retorna o nº de produtos no armazém
	free_tree(head);
}