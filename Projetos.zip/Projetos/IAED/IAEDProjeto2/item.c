
#include "item.h"

/* Definição das operações com Item */

Item new_obj (ULI chave, int quantidade)			// Define o objeto em função da sua chave e quantidade
{
	Item x = (Item)malloc(sizeof(struct objeto));	// Reserva espaço para o novo objeto
	x->ch = chave;
	x->qtd = quantidade;
	return x;
}

void print_obj (Item x)
{
	printf("%08lx %d\n", x->ch, x->qtd);			// Faz print dos objetos com 8 dígitos (complementado com zeros à esquerda se a chave tiver menos de 8 dígitos)
}

int less (Item a, Item b)
{
	return (a->ch < b->ch);		// Um Item a é menor que um b se e só se o número em hexadecimal for menor
}

int eq (Item a, Item b)
{
	return (a->ch == b->ch);	// São iguais se tiverem o mesmo número correspondente à chave
}


/* Implementação de ATD */

void init (link *head)
{
	*head = NULL;	// Raiz
}

link new_item (Item i, link l, link r)				// Definição de um novo link em função do Item e os
{													// valores dos pointers para a esquerda e direita da árvore
	link x = (link)malloc(sizeof(struct node));		// Reserva o espaço
	x->item = i;
	x->l = l;
	x->r = r;
	x->height = 1;
	return x;
}

void modify_item (link h, Item i)			// Alteração de um objeto (caso este já exista na árvore)
{
	if ((((h->item)->qtd) < -(i->qtd)))		// Se a quantidade a retirar for maior do que a existente no armazém
		(h->item)->qtd = 0;					// então define como nula a quantidade do item no armazém
	else									// Caso contrário
	{
		(h->item)->qtd += i->qtd;			// (acrescenta unidades, e o valor a retirar mantém-se positivo ou nulo)
		if (check && (((h->item)->qtd > obj_mais_freq->qtd) || (((h->item)->qtd == obj_mais_freq->qtd)
		&& (less(h->item, obj_mais_freq)))))
			obj_mais_freq = h->item;				// Se o novo valor da quantidade do item for superior (ou, se igual, com ordem lexigráfica menor)
	}												// então atualiza a variável "obj_mais_freq"
	if (i->qtd < 0 && eq(h->item, obj_mais_freq))	// Se retirar unidades ao objeto que era até ao momento o mais frequente, então
		check = 0;									// terá de verificar novamente com a função "stock" qual o objeto com maior stock no armazém
}

void stock (link h)				// Percorre, através da função recursiva, todos os objetos da árvore,
{								// atualizando a variável "obj_mais_freq"
	if (h == NULL)				// Termina a ramificação atual (quando chega à ponta)
		return;
	else if (((h->item)->qtd > obj_mais_freq->qtd) || (((h->item)->qtd == obj_mais_freq->qtd)
		&& (less(h->item, obj_mais_freq))))			
		obj_mais_freq = h->item;			// Se o novo valor da quantidade do item for superior então atualiza a variável "obj_mais_freq"
	stock(h->l);
	stock(h->r);				// Verifica para os ramos do lado esquerdo e direito
}

link insert (link h, Item i)	// A função insere o Item i na árvore
{
	Item v = i;
	if (h == NULL)				// Se o item não existe ainda na árvore, então
	{							// usa a função new_item para criar um novo
		num_obj_dif++;			// Incrementa o nº de objetos diferentes
		if (i->qtd < 0)			// Caso o valor do novo produto seja negativo,
			i->qtd = 0;			// assume um nº de unidades igual a zero para esse novo produto
		if (check && ((i->qtd) > (obj_mais_freq->qtd) || (((i->qtd) == obj_mais_freq->qtd) &&
			(less(i, obj_mais_freq)))))
			obj_mais_freq = i;				// Se o valor da quantidade do novo item for superior ao da variável "obj_mais_freq", então atualiza-a
		return new_item (i, NULL, NULL);
	}
	else if (less(v, h->item))		// Se a chave do item é menor que o elemento da árvore atual
		h->l = insert (h->l, i);	// insere à sua esquerda
	else if (less(h->item, v))		// Se for superior
		h->r = insert(h->r, i);		// coloca à direita
	else 						// Se esse item já existir
		modify_item (h, i);		// então altera a sua quantidade com a função "modify_item"
	h = AVLbalance(h);			// Ajusta a nova árvore de modo a que fique equilibrada
	return h;
}

link max (link h)						// O elemento máximo corresponde ao objeto mais à direita da árvore
{
	if (h == NULL || h->r == NULL)		// Quando chega ao fim
		return h;						// devolve o valor desse link
	else
		return max(h->r);
}

void sort (link h)				// Percorre toda a árvore ordenada
{
	if (h == NULL)	
		return;
	sort (h->l);				// Visita a raíz depois do filho esquerdo
	print_obj (h->item);
	sort (h->r);				// e antes do direito
}

link search (link h, Item i)		// Procura o Item i na árvore
{
	if (h == NULL)
		return NULL;				// Retorna 'NULL' (false) se não existir
	if (eq(i, h->item))
		return h;					// Retorna o valor do item h quando este tiver chave igual ao do item procurado 
	if (less(i, h->item))
		return search(h->l, i);		// Enquanto isso, varre nos filhos esquerdo e direito
	else
		return search(h->r, i);
}

link delete (link h, Item i)				// A função remove o elemento i da árvore
{
	link aux;
	if (h == NULL)					// Se a árvore estiver vazia, mantém inalterada a "head"
		return h;
	else if (less(i, h->item))		// Se a chave do item é menor que o elemento da árvore atual
		h->l = delete(h->l, i);		// recorre à mesma função à sua esquerda
	else if (less(h->item, i))		// Se a chave for superior
		h->r = delete(h->r, i);		// retira na sub-árvore à sua direita
	else
	{
		if (h->l != NULL && h->r != NULL)		// Para remover um nodo interno,
		{
			aux = max (h->l);					// substitui-se o elemento a remover pelo
			Item x = h->item;					// maior do elementos à esquerda do elemento
			h->item = aux->item;				// a ser removido
			aux->item = x;						// e remove-se esse elementos que ocorre nas
			h->l = delete (h->l, aux->item);	// seguintes condições
		}
		else
		{
			aux = h;
			if (h->l == NULL && h->r == NULL)	// Se o nodo não tiver filhos,
				h = NULL;						// basta apagar
			else if (h->l == NULL)				// Se tiver só um filho redireciona
				h = h->r;						// o filho à direita ou esquerda para esse, e,
			else 								// de seguida, remove-se esse filho
				h = h->l;
			free (aux->item);
			free (aux);
		}
	}
	h = AVLbalance(h);		// Após retirado o elemento, equilibra a árvore
	return h;
}

void free_tree(link h)		// Desocupa a memória de todos os ponteirs
{							// dos elementos da árvore
	if (h == NULL)
		return;
	free_tree(h->l);
	free_tree(h->r);
	free(h->item);
	free(h);
}

/* AVL (Definição das Árvores Binárias de Pesquisa Equilibradas) */

link rotL (link h)
{
	link x = h->r;
	h->r = x->l;
	x->l = h;
	update_height(h);
	update_height(x);
	return x;
}

link rotR (link h)
{
	link x = h->l;
	h->l = x->r;
	x->r = h;
	update_height(h);
	update_height(x);
	return x;
}

void update_height(link h)
{
	int height_left = height(h->l);
	int height_right = height(h->r);
	h->height = height_left > height_right ? height_left + 1 : height_right + 1;
}

int height (link h)
{
	if (h == NULL)
		return 0;
	return h->height;
}

link rotLR (link h)					// Rotação dupla esquerda direita
{
	if (h == NULL)
		return h;
	h->l = rotL(h->l);
	return rotR(h);
}

link rotRL (link h) 				// Rotação dupla direita esquerda
{
	if (h == NULL)
		return h;
	h->r = rotR(h->r);
	return rotL(h);
}
int Balance(link h)					// Balance factor
{
	if (h == NULL)
 		return 0;
	return height(h->l)-height(h->r);
}

link AVLbalance(link h)
{
	int balanceFactor;
	if (h == NULL)
		return h;
	balanceFactor = Balance(h);
	if (balanceFactor > 1)
	{
		if (Balance(h->l) >= 0)
			h=rotR(h);
		else
			h=rotLR(h);
	}
	else if (balanceFactor < -1)
	{
		if (Balance(h->r)<=0) h = rotL(h);
		else
			h = rotRL(h);
	}
	else
		update_height(h);
	return h;
}