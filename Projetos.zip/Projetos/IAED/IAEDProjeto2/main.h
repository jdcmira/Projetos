
#ifndef MAIN
#define MAIN


/* Bibliotecas a utilizar */

#include <stdio.h>
#include <stdlib.h>


/* Ficheiros utilizados, "command.h" tem os comandos do input onde executa as operações com base nas funções de "item.h" */

#include "command.h"
#include "item.h"


/* "num_obj_dif" é a variável que indica o nº de chaves diferentes guardados no sistema indicado antes de terminar
o programa, e é atualizada sempre que se acrescenta um novo produto ao armazém ou quando se retira um. "check" é a variável
para a o comando 'm', que tem o valor true (1) sempre que não necessita de recorrer à função "stock" (que percorre a
árvore para determinar a chave com maior stock no armazém) e false (0) quando tem de verificar (subentende-se, para
este caso, que corresponde a obj_mais_freq = NULL). "obj_mais_freq" é o Item (do tipo estrutura do objeto) que tem
o valor do objeto da árvore com maior stock (desta forma, é válido quando check == 1). */

int num_obj_dif, check;
link head;
Item obj_mais_freq;

#endif