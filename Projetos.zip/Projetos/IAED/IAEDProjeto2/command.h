
#include "main.h"

#ifndef COMMAND
#define COMMAND


/* Funções-protótipo dos comandos do input. "command.c" é a interface de operações sobre tipo de dados,
onde as funções "de baixo nível" são implementadas em "item.c" (com a definição das estruturas de dados e
e funções especificadas) */

void a_addproduct();
void l_sort();
void m_stock();
void r_remproduct();
void x_closeapp();

#endif